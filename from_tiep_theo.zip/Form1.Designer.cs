﻿namespace from_tiep_theo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lvCommected = new ListView();
            btDiscomect = new Button();
            label2 = new Label();
            lvReceived = new ListView();
            label3 = new Label();
            txtServerSatus = new TextBox();
            btStart = new Button();
            btStop = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(24, 27);
            label1.Name = "label1";
            label1.Size = new Size(131, 17);
            label1.TabIndex = 0;
            label1.Text = "Commected Clients:";
            // 
            // lvCommected
            // 
            lvCommected.BackColor = Color.Gainsboro;
            lvCommected.Location = new Point(23, 55);
            lvCommected.Name = "lvCommected";
            lvCommected.Size = new Size(473, 158);
            lvCommected.TabIndex = 1;
            lvCommected.UseCompatibleStateImageBehavior = false;
            // 
            // btDiscomect
            // 
            btDiscomect.BackColor = Color.Crimson;
            btDiscomect.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btDiscomect.ForeColor = SystemColors.ButtonHighlight;
            btDiscomect.Location = new Point(531, 55);
            btDiscomect.Name = "btDiscomect";
            btDiscomect.Size = new Size(213, 58);
            btDiscomect.TabIndex = 2;
            btDiscomect.Text = "Discomect Client";
            btDiscomect.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(21, 236);
            label2.Name = "label2";
            label2.Size = new Size(129, 17);
            label2.TabIndex = 3;
            label2.Text = "Received Messages:";
            // 
            // lvReceived
            // 
            lvReceived.BackColor = Color.Gainsboro;
            lvReceived.Location = new Point(25, 276);
            lvReceived.Name = "lvReceived";
            lvReceived.Size = new Size(831, 175);
            lvReceived.TabIndex = 4;
            lvReceived.UseCompatibleStateImageBehavior = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(25, 471);
            label3.Name = "label3";
            label3.Size = new Size(93, 17);
            label3.TabIndex = 5;
            label3.Text = "Server Status:";
            // 
            // txtServerSatus
            // 
            txtServerSatus.Location = new Point(155, 471);
            txtServerSatus.Multiline = true;
            txtServerSatus.Name = "txtServerSatus";
            txtServerSatus.Size = new Size(372, 32);
            txtServerSatus.TabIndex = 6;
            // 
            // btStart
            // 
            btStart.BackColor = Color.ForestGreen;
            btStart.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btStart.ForeColor = SystemColors.ButtonHighlight;
            btStart.Location = new Point(557, 464);
            btStart.Name = "btStart";
            btStart.Size = new Size(136, 39);
            btStart.TabIndex = 7;
            btStart.Text = "Start Server";
            btStart.UseVisualStyleBackColor = false;
            // 
            // btStop
            // 
            btStop.BackColor = SystemColors.ControlDarkDark;
            btStop.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btStop.ForeColor = SystemColors.ButtonHighlight;
            btStop.Location = new Point(720, 464);
            btStop.Name = "btStop";
            btStop.Size = new Size(136, 39);
            btStop.TabIndex = 8;
            btStop.Text = "Stop Server";
            btStop.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(908, 572);
            Controls.Add(btStop);
            Controls.Add(btStart);
            Controls.Add(txtServerSatus);
            Controls.Add(label3);
            Controls.Add(lvReceived);
            Controls.Add(label2);
            Controls.Add(btDiscomect);
            Controls.Add(lvCommected);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form Server - Chatbox Secure";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListView lvCommected;
        private Button btDiscomect;
        private Label label2;
        private ListView lvReceived;
        private Label label3;
        private TextBox txtServerSatus;
        private Button btStart;
        private Button btStop;
    }
}
